import HeadNav from './HeadNav';

export default HeadNav;
