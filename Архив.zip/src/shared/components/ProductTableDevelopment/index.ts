import {ProductTableDevelopment} from './ProductTableDevelopment';

export default ProductTableDevelopment;
