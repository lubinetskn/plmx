import {ModalPLMX} from './Modal';

export default ModalPLMX;
