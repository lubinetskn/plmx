import {ProductTableMarketing} from './ProductTableMarketing';

export default ProductTableMarketing;
