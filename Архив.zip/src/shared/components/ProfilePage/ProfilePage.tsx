import React from 'react';
import Container, {StyledButton} from './styled';

const ProfilePage = () => (
  <Container>
    <StyledButton>Hello</StyledButton>
  </Container>
);

export default ProfilePage;
