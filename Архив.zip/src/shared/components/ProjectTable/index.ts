import {ProjectTable} from './ProjectTable';

export default ProjectTable;
