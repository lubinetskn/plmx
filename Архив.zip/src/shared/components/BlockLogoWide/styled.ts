import styled from 'styled-components';

export const TypoWrapper = styled.div`
  width: 138px;
  margin-left: 9px;
`;
