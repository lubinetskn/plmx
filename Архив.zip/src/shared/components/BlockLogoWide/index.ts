import BlockLogoWide from './BlockLogoWide';

export default BlockLogoWide;
