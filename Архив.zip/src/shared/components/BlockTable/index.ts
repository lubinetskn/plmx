import BlockTable from './BlockTable';

export default BlockTable;
