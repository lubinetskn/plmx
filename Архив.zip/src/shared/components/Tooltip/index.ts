import {StyledTooltip} from './Tooltip';

export default StyledTooltip;
