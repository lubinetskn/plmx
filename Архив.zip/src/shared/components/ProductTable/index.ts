import {ProductTable} from './ProductTable';

export default ProductTable;
