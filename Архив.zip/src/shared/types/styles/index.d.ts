declare module '*.less' {
  const content: any;
  export default content;
}
