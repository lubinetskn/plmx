const moduleName = 'products';
export default moduleName;
