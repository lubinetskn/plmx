export interface ProductsState {
  products: [];
  tasks: {};
  isLoading: boolean;
  error: string;
}
