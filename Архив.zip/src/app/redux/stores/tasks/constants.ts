const moduleName = 'tasks';
export default moduleName;
