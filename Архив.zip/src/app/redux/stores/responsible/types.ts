export interface ResponsibleState {
  responsible: [];
  isLoading: boolean;
  error: string;
}
