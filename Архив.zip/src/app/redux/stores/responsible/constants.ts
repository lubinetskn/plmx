const moduleName = 'responsible';
export default moduleName;
