const moduleName = 'widget';
export default moduleName;
