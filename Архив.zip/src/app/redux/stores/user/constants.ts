const moduleName = 'user';
export default moduleName;
