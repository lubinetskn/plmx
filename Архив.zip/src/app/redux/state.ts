const initialState = {
  test: false,
  login: null,
};
export default initialState;
