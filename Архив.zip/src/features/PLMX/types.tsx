export const PRODUCT_GET_TASKS = 'PRODUCT_GET_TASKS';

export const PRODUCT_GET_TASKS_SUCCESS = 'PRODUCT_GET_TASKS_SUCCESS';

export interface IPLMX {
  [key: string]: any;
}
