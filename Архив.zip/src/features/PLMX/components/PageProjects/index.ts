import PageProjects from './PageProjects';

export default PageProjects;
