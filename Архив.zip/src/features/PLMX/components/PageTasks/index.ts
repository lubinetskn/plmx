import PageTasks from './PageTasks';

export default PageTasks;
