import WidgetList from './WidgetList';

export default WidgetList;
