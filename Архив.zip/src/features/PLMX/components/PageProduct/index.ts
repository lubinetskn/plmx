import PageProduct from './PageProduct';

export default PageProduct;
