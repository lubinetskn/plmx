export {default} from './PageNewPassword';
