export interface ILoginPair {
  email: string;
  password: string;
}
