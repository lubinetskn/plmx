import PageLogin from './PageLogin';

export default PageLogin;
